
// Runtime environment configuration
window.ENV = {
  "NEXT_PUBLIC_EMAILJS_SERVICE_ID": "service_958ibxe",
  "NEXT_PUBLIC_EMAILJS_TEMPLATE_ID": "template_5gfc4zi",
  "NEXT_PUBLIC_EMAILJS_PUBLIC_KEY": "EMvss3sajXe2nwsjP"
};
