# Netlify Drag and Drop Deployment

## Instructions

1. Navigate to https://app.netlify.com/ and log in to your account
2. Drag and drop this entire folder onto the Netlify dashboard
3. Wait for the deployment to complete
4. Access your site at the URL provided by Netlify

## Environment Variables

This package includes a .env file with EmailJS configuration. Before deploying:

1. Open the .env file in this folder
2. Replace the placeholder values with your actual EmailJS credentials:
   - NEXT_PUBLIC_EMAILJS_SERVICE_ID
   - NEXT_PUBLIC_EMAILJS_TEMPLATE_ID
   - NEXT_PUBLIC_EMAILJS_PUBLIC_KEY

Alternatively, you can set these variables in the Netlify dashboard after deployment:
1. Go to Site settings > Environment variables
2. Add each variable with your actual values
3. Trigger a new deployment

## Important Notes

- This deployment method is separate from your GitHub-connected deployment
- Any changes will require generating a new package and redeploying
- To generate a new package, run `npm run build-for-deploy` in the main project

